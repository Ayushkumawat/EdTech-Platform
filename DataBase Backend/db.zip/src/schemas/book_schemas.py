from pydantic import BaseModel, Field
from typing import Optional
import uuid
from .chapter_schemas import ChapterOut
from .review_schemas import ReviewOut

class BookBase(BaseModel):
    name: str
    medium: str
    subject_id: uuid.UUID
    teacher: str
    duration: str
    description: str

class BookCreate(BookBase):
    pass

class BookUpdate(BaseModel):
    name: Optional[str] = None
    medium: Optional[str] = None
    subject_id: Optional[uuid.UUID] = None
    teacher: Optional[str] = None
    duration: Optional[str] = None

class BookListOut(BookBase):
    uid: uuid.UUID
    class Config:
        orm_mode = True

class BookOut(BookBase):
    uid: uuid.UUID
    chapters: Optional[list[ChapterOut]] = []
    reviews: Optional[list[ReviewOut]] = []

    class Config:
        orm_mode = True
        