from pydantic import BaseModel, Field
from typing import Optional
import uuid

class ClassBase(BaseModel):
    name: str
    description: Optional[str] = None
    board: str

class ClassCreate(ClassBase):
    pass

class ClassUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    board: Optional[str] = None

class ClassOut(ClassBase):
    uid: uuid.UUID
    class Config:
        orm_mode = True
